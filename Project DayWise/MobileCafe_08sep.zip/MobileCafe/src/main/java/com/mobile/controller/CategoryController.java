package com.mobile.controller;
//import java.util.*;
import com.mobile.dao.CategoryDAO;
import com.mobile.model.Category;

//import com.mobile.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CategoryController 
{
	@Autowired
	CategoryDAO cdao;
	
	//To display the Category Page
	@RequestMapping(value="/AddCategory",method=RequestMethod.GET)
	public ModelAndView showCategory(Model m)
	{
		ModelAndView mv=new ModelAndView("AddCategory","category",new Category());
		return mv;
	}
	
	//Getting values from Category Page
	@RequestMapping(value="/AddCategory",method=RequestMethod.POST)
	public String addCategory(Category category,Model m)
	{
		//System.out.println(category.getCid());
		//System.out.println(category.getCname());
		
		cdao.addCProduct(category);
		//System.out.println("Added to database");
		return "AddCategory"; 
		
	}

}
