package com.mobile.dao;


import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mobile.model.Category;


@Transactional
@Repository
public class CategoryDAO 
{
	@Autowired
	SessionFactory sessionFactory;
	
	public void addCProduct(Category c)
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		session.save(c);
		tx.commit();
	}
	
}
