package com.mobile.model;


public class Register 
{
String name;
String uname;
String mobno;
String email;
String pwd;
String cpwd;
public Register()
{
	
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getMobno() {
	return mobno;
}
public void setMobno(String mobno) {
	this.mobno = mobno;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getCpwd() {
	return cpwd;
}
public void setCpwd(String cpwd) {
	this.cpwd = cpwd;
}

}
