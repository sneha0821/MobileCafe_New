package com.mobile.dao;


import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mobile.model.Category;

import antlr.collections.List;


@Transactional
@Repository
public class CategoryDAO 
{
	@Autowired
	SessionFactory sessionFactory;
	
	public void addCProduct(Category c)
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		session.save(c);
		tx.commit();
	}
	
	public List showCategory()
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List showcat=(List) session.createQuery("From Category");
		tx.commit();
		return showcat;
	}
	
	public void editCategory(Category c)
	{
		Session session=sessionFactory.openSession();
		Transaction tx=	session.getTransaction();
		session.update(c);
		tx.commit();
		
	}
}
