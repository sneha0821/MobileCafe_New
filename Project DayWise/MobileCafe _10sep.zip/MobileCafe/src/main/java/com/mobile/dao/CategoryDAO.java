package com.mobile.dao;


import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mobile.model.Category;

import java.util.*;

@Repository
public class CategoryDAO 
{
	@Autowired
	SessionFactory sessionFactory;
	
	public void addCProduct(Category c)
	{
		System.out.println("Category Product DAO");
		System.out.println(c.getCid());
		System.out.println(c.getCname());
		try
		{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		//tx.begin();
		session.save(c);
		tx.commit();
		session.close();
		}
		catch(Exception e)
		{
			System.out.println("Error"+e);
		}
	}
	
	public List showCategory()
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List showcat=session.createQuery("from Category").list();
		tx.commit();
		session.close();
		return showcat;
	}
	
	public void editCategory(Category c)
	{
		Session session=sessionFactory.openSession();
		Transaction tx=	session.getTransaction();
		tx.begin();
		session.update(c);
		tx.commit();
		
	}
	public void deleteCategory(int delcatid)
	{
		Session session = sessionFactory.openSession();
	      Transaction tx = session.getTransaction();
	      tx.begin();
	        Category c=(Category)session.get(Category.class,delcatid);
	        System.out.println(c);
	         session.delete(c); 
	         tx.commit();
	}
	
	
}
