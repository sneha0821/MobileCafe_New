package com.mobile.dao;
import java.util.*;

import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.mobile.model.Product;

@Repository
public class ProductDAO
{
	
	List<Product> myprod =new ArrayList<Product>();
	public String addProduct()
	{
		Gson gson=new Gson();
		String jsonInString=gson.toJson(myprod);
		return jsonInString;
		
	}
	
	
	
}
