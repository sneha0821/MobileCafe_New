package com.mobile.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mobile.dao.ProductDAO;
import com.mobile.model.Product;

@Controller
public class ProductController 
{
	/**
	 * @Autowired
	ProductDAO pdao;
	@RequestMapping("/Product")
	public String showProduct(Model m)
	{
	System.out.println("Category Product DAO");
	//System.out.println(c.getCid());
	//System.out.println(c.getCname());
	try
	{
	Session session=sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	//tx.begin();
	session.save(c);
	session.flush();
	tx.commit();
	session.close();
	}
	catch(Exception e)
	{
		System.out.println("Error"+e);
	}
	}
	 * 
	 */
	


}
